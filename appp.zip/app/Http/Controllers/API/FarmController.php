<?php

namespace App\Http\Controllers\API;

use App\Enums\Crop;
use App\Enums\IrrigationSource;
use App\Enums\SeedVariety;
use App\Enums\SoilType;
use App\Enums\SowingMethod;
use App\Http\Controllers\Controller;
use App\Http\Requests\FarmRequest;
use App\Models\FarmConfiguration;
use App\Models\Project;
use App\Models\UserFarm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use OpenApi\Annotations as OA;

class FarmController extends BaseController
{
    /**
     *     @OA\Post(
     *         path="/api/add-farm-details",
     *         tags={"Farm"},
     *         summary="Create a new farm",
     *         description="Creates a new farm with location, size, and configuration details.",
     *         @OA\RequestBody(
     *             required=true,
     *             @OA\MediaType(
     *                mediaType="multipart/form-data",
     *                @OA\Schema(
     *                   type="object",
     *                   required={
     *                      "location",
     *                      "size",
     *                      "latitude",
     *                      "longitude",
     *                      "irrigation_source",
     *                      "soil_type",
     *                      "sowing_method",
     *                      "seed_variety",
     *                      "crop",
     *                      "sowing_date",
     *                      "farm_configuration"
     *                   },
     *                   @OA\Property(property="location", type="string", example="Kampala"),
     *                   @OA\Property(property="size", type="string", example="10"),
     *                   @OA\Property(property="latitude", type="string", example="0.3131"),
     *                   @OA\Property(property="longitude", type="string", example="32.5811"),
     *                   @OA\Property(property="irrigation_source", type="integer", example=1),
     *                   @OA\Property(property="soil_type", type="integer", example=1),
     *                   @OA\Property(property="sowing_method", type="integer", example=1),
     *                   @OA\Property(property="seed_variety", type="integer", example=1),
     *                   @OA\Property(property="crop", type="integer", example=1),
     *                   @OA\Property(property="sowing_date", type="string", example="2021-09-01"),
     *                   @OA\Property(property="name", type="string", example="Farm 1"),
     *                   @OA\Property(property="farm_configuration",
     *                      type="array",
     *                      @OA\Items(
     *                          type="object",
     *                          @OA\Property(property="latitude", type="number", example=1),
     *                          @OA\Property(property="longitude", type="number", example=10),
     *                          @OA\Property(property="id", type="integer", example=1)
     *                      )
     *                   )
     *                ),
     *             ),
     *         ),
     *         @OA\Response(
     *             response=201,
     *             description="Farm created successfully",
     *             @OA\JsonContent()
     *         ),
     *         @OA\Response(
     *             response=200,
     *             description="Farm created successfully",
     *             @OA\JsonContent()
     *         ),
     *         @OA\Response(
     *             response=422,
     *             description="Unprocessable Entity",
     *             @OA\JsonContent()
     *         ),
     *         @OA\Response(
     *             response=400,
     *             description="Bad request",
     *             @OA\JsonContent()
     *         ),
     *         @OA\Response(
     *             response=404,
     *             description="Resource Not Found",
     *             @OA\JsonContent()
     *         ),
     *     )
     */


    public function addFarmDetails(FarmRequest $request)
    {
        $data = $request->validated();
        $data['user_id'] = auth()->user()->id;
        $data['farm_configuration'] = json_encode($data['farm_configuration']);

        UserFarm::create($data);
        $data = UserFarm::where('user_id',auth()->user()->id)->get();
        $data->map(function ($farm) {
            $farm->farm_configuration = json_decode($farm->farm_configuration,true);
            return $farm;
        });
        return $this->sendResponse($data, 'Farm details added successfully');
    }

    /**
     * @OA\Get(
     *     path="/api/get-farm-list",
     *     tags={"Farm"},
     *     summary="Get list of farms for the authenticated user",
     *     operationId="getFarmList",
     *     security={{"Bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Farm details retrieved successfully",
     *
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="Unauthenticated.")
     *         )
     *     ),
     *     @OA\Response(response=400, description="Bad request"),
     *     @OA\Response(response=404, description="Resource Not Found"),
     * )
     */
    public function getFarmList(Request $request)
    {
        // with related data
        $data = UserFarm::with('irrigationSource', 'soilType', 'sowingMethod', 'seedVariety', 'crop')->where('user_id', auth()->user()->id)->get();
        $data->map(function ($farm) {
            $farm->farm_configuration = json_decode($farm->farm_configuration,true);
            return $farm;
        });
        return $this->sendResponse($data, 'Farm details retrieved successfully');
    }

    public function getAllFarms()
    {
        $data = Project::all();
        return $this->sendResponse($data, 'Farm details retrieved successfully');
    }

    /**
     * Display available enum options.
     *
     * @OA\Get(
     *     path="/api/farm/enums",
     *     summary="Get available enums for farm",
     *     tags={"Farm"},
     *     security={{"Bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="List of Enums",
     *         @OA\JsonContent(
     *             @OA\Property(property="irrigation_source", type="array", @OA\Items(type="string")),
     *             @OA\Property(property="soil_type", type="array", @OA\Items(type="string")),
     *             @OA\Property(property="sowing_method", type="array", @OA\Items(type="string")),
     *             @OA\Property(property="seed_variety", type="array", @OA\Items(type="string")),
     *             @OA\Property(property="crop", type="array", @OA\Items(type="string")),
     *         )
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthorized"
     *     )
     * )
     */
    public function getEnums(): \Illuminate\Http\JsonResponse
    {
        return response()->json([
            'irrigation_source' => IrrigationSource::cases(),
            'soil_type' => SoilType::cases(),
            'sowing_method' => SowingMethod::cases(),
            'seed_variety' => SeedVariety::cases(),
            'crop' => Crop::cases(),
        ]);
    }


}
