<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\Wallet;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;


class WalletController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/wallet",
     *     summary="Get wallet balances",
     *     tags={"Wallet"},
     *     security={{"Bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Successful operation",
     *         @OA\JsonContent(
     *             @OA\Property(property="available_balance", type="number", format="float"),
     *             @OA\Property(property="cash_balance", type="number", format="float"),
     *             @OA\Property(property="reward_balance", type="number", format="float")
     *         )
     *     )
     * )
     */
    public function getWallet()
    {
        $wallet = Auth::user()->wallet;
        // check if exists
        if ($wallet) {
            return response()->json([
                'available_balance' => $wallet->cash_balance + $wallet->rewards_balance,
                'cash_balance' => $wallet->cash_balance,
                'reward_balance' => $wallet->rewards_balance,
            ]);
        }
        return response()->json([
            'available_balance' => 0.00,
            'cash_balance' => 0.00,
            'reward_balance' => 0.00,
        ]);
    }

    /**
     * @OA\Post(
     *     path="/api/wallet/add-funds",
     *     summary="Add funds to wallet",
     *     tags={"Wallet"},
     *     security={{"Bearer":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="amount", type="number", format="float"),
     *             @OA\Property(property="type", type="string", enum={"cash", "rewards"})
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Funds added successfully"
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid input"
     *     )
     * )
     */
    public function addFunds(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'type' => 'required|in:cash,rewards',
        ]);

        $wallet = Auth::user()->wallet;
        $amount = $request->amount;
        $type = $request->type;
        if($wallet){

            if ($type === 'cash' ) {
                $wallet->cash_balance += $amount;
            } else {
                $wallet->rewards_balance += $amount;
            }

            $wallet->save();
        }else{
            $wallet = Wallet::create([
                'user_id' => Auth::id(),
                'cash_balance' => 0.00,
                'rewards_balance' => 0.00,
            ]);

            if ($type === 'cash') {
                $wallet->cash_balance += $amount;
            } else {
                $wallet->rewards_balance += $amount;
            }

            $wallet->save();
        }

        Transaction::create([
            'wallet_id' => $wallet->id,
            'amount' => $amount,
            'type' => 'credit',
            'description' => ucfirst($type) . ' Funds Added',
        ]);

        return response()->json(['message' => 'Funds added successfully.']);
    }

    /**
     * @OA\Post(
     *     path="/api/wallet/withdraw",
     *     summary="Withdraw funds from wallet",
     *     tags={"Wallet"},
     *     security={{"Bearer":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="amount", type="number", format="float"),
     *             @OA\Property(property="type", type="string", enum={"cash", "rewards"})
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Funds withdrawn successfully"
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Insufficient balance"
     *     )
     * )
     */
    public function withdrawFunds(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:0.01',
            'type' => 'required|in:cash,rewards',
        ]);

        $wallet = Auth::user()->wallet;
        $amount = $request->amount;
        $type = $request->type;

        if ($type === 'cash') {
            if ($wallet->cash_balance < $amount) {
                return response()->json(['message' => 'Insufficient cash balance.'], 400);
            }
            $wallet->cash_balance -= $amount;
        } else {
            if ($wallet->rewards_balance < $amount) {
                return response()->json(['message' => 'Insufficient rewards balance.'], 400);
            }
            $wallet->rewards_balance -= $amount;
        }

        $wallet->save();

        Transaction::create([
            'wallet_id' => $wallet->id,
            'amount' => -$amount,
            'type' => 'debit',
            'description' => ucfirst($type) . ' Withdrawal',
        ]);

        return response()->json(['message' => 'Funds withdrawn successfully.']);
    }

    /**
     * @OA\Get(
     *     path="/api/wallet/transactions",
     *     summary="Get wallet transactions",
     *     tags={"Wallet"},
     *     security={{"Bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Successful operation",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Transaction"))
     *     )
     * )
     */
    public function getTransactions()
    {
        $transactions = Auth::user()->wallet->transactions()->orderBy('created_at', 'desc')->get();

        return response()->json($transactions);
    }
}
